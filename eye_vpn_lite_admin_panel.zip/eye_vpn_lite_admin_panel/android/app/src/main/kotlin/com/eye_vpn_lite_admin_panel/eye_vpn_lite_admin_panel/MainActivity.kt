package com.eye_vpn_lite_admin_panel.eye_vpn_lite_admin_panel

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
